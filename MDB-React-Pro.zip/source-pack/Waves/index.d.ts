export { default } from './Waves';
export * from './Waves';