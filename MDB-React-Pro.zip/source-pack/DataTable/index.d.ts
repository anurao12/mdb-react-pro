export { default } from './DataTable';
export * from './DataTable';