export { default } from './TabContent';
export * from './TabContent';