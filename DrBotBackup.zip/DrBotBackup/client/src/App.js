import React, { Component } from 'react';
import {
  MDBNavbar,
  MDBFooter,
  MDBBtn
} from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
// import {connect} from 'react-redux';
import Routes from './Routes';
import mphasis_logo from './assets/mphasis_logo.png';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './app.css';

toast.configure();
class App extends Component {

  // renderButton = () => {
  //   if(this.props.auth){
  //     return(
  //       <MDBBtn style={{ marginLeft: '80%' }}>LogOut</MDBBtn>
  //     );
  //   }
  //   else{
  //     return(
  //       <MDBBtn style={{ marginLeft: '80%' }}>Login</MDBBtn>
  //     );
  //   }
    
  // }

  renderHeader = () => {
    return (
      <div>
        <MDBBtn style={{ marginLeft: '1080px' }}>LogOut</MDBBtn>
      </div>

    );
  }

  render() {
    return (
      <Router>
        <div className='flyout'>
          <MDBNavbar color='indigo' dark expand='md' fixed='top' scrolling>
            <img id="logo" src={mphasis_logo} alt="your logo" height="40px" />
            {this.renderHeader()}
          </MDBNavbar>
          <main className='mainImage'>
            <Routes />
          </main>
          <MDBFooter color='indigo'>
            <p className='footer-copyright mb-0 py-3 text-center'>
              &copy; {new Date().getFullYear()}
              <a href='https://www.mphasis.com'> Mphasis. </a> All rights reserved
            </p>
          </MDBFooter>
        </div>
      </Router>
    );
  }
}

// function mapStateToProps(state){
//   return { 
//     auth: state.auth
//   };
// }

export default App;
