import React, { Component } from "react";
import {
  MDBRow,
  MDBCol,
  MDBInput,
  MDBBtn,
  MDBCardBody,
  MDBDataTableV5,
  MDBCard,
  MDBSelect,
} from "mdbreact";
import axios from "axios";
import SectionContainer from "../../SectionContainer";
import "./ApplicationInfo.css";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const myHeaders = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
};

class ApplicationInfo extends Component {
  state = {
    app_name: "",
    app_url: "",
    app_type: [],
    isUpdate: false,
    isDelete: false,
    processName: [],
    selectedAppType: "",
    selectedProcessName: "",
    id: 0,
    data: {
      columns: [],
      rows: [],
    },
  };

  changeHandler = (e) => {
    e.preventDefault();
    this.setState({ [e.target.id]: e.target.value });
  };

  AppOptionHandler = (f) => {
    this.setState({ selectedProcessName: f });
  };

  optionTypeHandler = (g) => {
    this.setState({ selectedAppType: g });
  };

  createOptions = () => [
    {
      text: "Web Application",
      value: "1",
    },
    {
      text: "Window Application",
      value: "2",
    },
  ];

  componentDidMount() {
    fetch("/appProcessList", { headers: myHeaders })
      .then((response) => response.json())
      .then((result) => {
        result.soapResult.ProcessList.map((item) => {
          item.value = item.value.toString();
        });
        //console.log(result.soapResult.ProcessList)
        this.setState({ processName: result.soapResult.ProcessList }, () =>
          localStorage.setItem(
            "dropdownValue",
            JSON.stringify(result.soapResult.ProcessList)
          )
        );
      });
    this.setState({ app_type: this.createOptions() });
    this.drawGrid();
  }

  drawGrid = () => {
    //console.log("here in grid");
    fetch("/applicationInfo", { headers: myHeaders })
      .then((response) => response.json())
      .then((result) => {
        const row = result.response.map((Key) => {
          Key["check"] = (
            <div>
              {" "}
              <i
                className="fa fa-pencil-square-o"
                onClick={() => {
                  this.showLogs(Key);
                }}
                aria-hidden="true"
              ></i>{" "}
              &nbsp;&nbsp;&nbsp; &nbsp;{" "}
              <i
                className="fa fa-trash"
                onClick={() => {
                  this.showLogsDel(Key);
                }}
                aria-hidden="true"
              ></i>
            </div>
          );
          // console.log(Key);

          return Key;
        });

        let col = [];
        col.push(
          {
            label: "Id",
            field: "app_id",
            width: 50,
            sort: "",
          },
          {
            label: "Applicaion Name",
            field: "app_name",
            width: 150,
            sort: "",
          },
          {
            label: "Application URL",
            field: "app_url",
            width: 200,
            sort: "",
          },
          {
            label: "Process Name",
            field: "process_name",
            width: 200,
            sort: "",
          },
          {
            label: "Application Type",
            field: "app_type_id",
            width: 150,
            sort: "",
          },
          {
            label: "Actions",
            field: "check",
            width: 150,
            sort: "",
          }
        );

        let data = {
          columns: col,
          rows: row,
        };
        // console.log("columns" + JSON.stringify(row));
        this.setState({ data });
      });

    if (localStorage.getItem("dropdownValue")) {
      this.setState({
        processName: JSON.parse(localStorage.getItem("dropdownValue")),
      });
    }

    
  };

  updateHandler = () => {
    // console.log(Key);
    const updateApp = {
      app_id: this.state.id,
      app_name: this.state.app_name,
      app_type_id: this.state.selectedAppType,
      app_url: this.state.app_url,
      process_name: this.state.selectedProcessName,
    };
    axios
      .put("/updateAppConfig", updateApp, { headers: myHeaders })
      .then((response) => {
        toast(response.data.message);
        this.setState({ isUpdate: false, isDelete: false }, () => {
          this.drawGrid(), this.resetForm();
        });
      })
      .catch((err) => console.log(err));
  };

  submitHandler = (e) => {
    e.preventDefault();
    const appData = {
      app_name: this.state.app_name,
      app_url: this.state.app_url,
      process_name: this.state.selectedProcessName,
      app_type_id: this.state.selectedAppType,
    };
    axios
      .post("/createApplicationInfo", appData, { headers: myHeaders })
      .then((response) => {
        toast(response.data.message);
        this.setState({ checked: true });
        this.drawGrid();
        this.resetForm();
      })
      .catch((err) => console.log(err));
  };

  resetForm = () => {
    this.setState({
      app_name: "",
      app_url: "",
      app_type: this.createOptions(),
      isDelete: false
    });
  };

  deleteHandler = () => {
    const deleteApp = {
      app_id: this.state.id,
    };
    axios
      .put("/deleteAppConfig", deleteApp, { headers: myHeaders })
      .then((response) => {
        toast(response.data.message);
        this.drawGrid();
        this.resetForm();
      })
      .catch((err) => console.log(err));
  };

  showLogsDel = (Key) => {
    this.setState({
      id: Key.app_id,
      isDelete: true,
    });
  };

  showLogs = (Key) => {
    this.setState({
      id: Key.app_id,
      app_name: Key.app_name,
      app_url: Key.app_url,
      isUpdate: true,
    });
    
    const prosDrop = this.state.processName.findIndex((element)=>{
      //console.log(element);
        return element.text === Key.process_name;
      })
      
      if(prosDrop >= 0){
        Object.assign(this.state.processName[prosDrop], { checked: true });
        this.setState(prevState => {
          let prevOptions = [...prevState.processName];
          prevOptions[prosDrop].checked = true;
          return { processName: prevOptions };
      })
      }

      const typeDrop = this.state.app_type.findIndex((element)=>{
        //console.log(element);
          return element.text === Key.app_type_id;
        })

        if(typeDrop >= 0){
          Object.assign(this.state.app_type[typeDrop], { checked: true });
          this.setState(prevState => {
            let prevOptions = [...prevState.app_type];
            prevOptions[typeDrop].checked = true;
            return { app_type: prevOptions };
        })
        }
  };

  render() {
    const { app_name, app_url, data, processName, app_type } = this.state;
    return (
      <div>
        <div>
          <h1>Application Data Configuration</h1>
          <form className="needs-validation" onSubmit={this.submitHandler}>
            <MDBRow>
              <MDBCol md="4">
                <MDBSelect
                  options={processName}
                  selected="Choose your option"
                  color="primary"
                  label="Process Name *"
                  getTextContent={this.AppOptionHandler}
                  required
                />
              </MDBCol>
            </MDBRow>

            <MDBRow>
              <MDBCol md="4">
                <MDBInput
                  value={app_name}
                  name="name"
                  onChange={this.changeHandler}
                  type="text"
                  id="app_name"
                  label="Application name *"
                  autoComplete="off"
                  onFocus={this.onFocus}
                  required
                ></MDBInput>
              </MDBCol>
            </MDBRow>

            <MDBRow>
              <MDBCol md="4">
                <MDBInput
                  value={app_url}
                  name="name"
                  onChange={this.changeHandler}
                  type="text"
                  id="app_url"
                  label="Application URL *"
                  autoComplete="off"
                  onFocus={this.onFocus}
                  required
                ></MDBInput>
              </MDBCol>
            </MDBRow>

            <MDBRow>
              <MDBCol md="4">
                <MDBSelect
                  options={app_type}
                  selected="Choose your Options"
                  color="primary"
                  label="Application Type *"
                  getTextContent={this.optionTypeHandler}
                  value={this.state.selectedUser}
                  required
                />
              </MDBCol>
            </MDBRow>

            {this.state.isUpdate ? (
              <MDBBtn color="success" onClick={this.updateHandler}>
                Update
              </MDBBtn>
            ) : (
              <MDBBtn
                color="success"
                style={{ marginBottom: "30px" }}
                type="submit"
              >
                Submit
              </MDBBtn>
            )}
          </form>
        </div>

        <div>
          <MDBRow className="py-3">
            {this.state.isDelete ? (
              <MDBBtn
                color="danger"
                onClick={this.deleteHandler}
                style={{ marginLeft: "700px" }}
              >
                Delete
              </MDBBtn>
            ) : null}

            <MDBCol md="12">
              <SectionContainer noBorder>
                <MDBCard>
                  <MDBCardBody>
                    {data["rows"].length > 0 ? (
                      <MDBDataTableV5
                        hover
                        entriesOptions={[5, 20, 25]}
                        entries={5}
                        pagesAmount={4}
                        data={data}
                      />
                    ) : null}
                  </MDBCardBody>
                </MDBCard>
              </SectionContainer>
            </MDBCol>
          </MDBRow>
        </div>
      </div>
    );
  }
}

export default ApplicationInfo;
