import React from 'react';
import './AdminPage.css';
import {
  MDBTreeview,
  MDBTreeviewList,
  MDBTreeviewItem,
  MDBCol,
  MDBRow,
  MDBContainer
} from 'mdbreact';
import ApplicationInfo from './ApplicationInfo/ApplicationInfo';
import VMHealthInfo from './VmHealthCheck/VmHealthInfo';
import NetworkHealthInfo  from './NetworkCheck/NetworkHealthInfo';
import ApplicationLogin from './ApplicationInfo/ApplicationLogin';

class AdminPage extends React.Component {
state = {
  currentComponent: '',
}

handleClickfor = (comp) => {
  this.setState({ currentComponent: comp });
}
  render() {
    return (
       <div style={{marginTop: '30px'}}>
      <MDBContainer fluid>
        <MDBRow>
          <MDBCol md="3">
            <MDBTreeview
              theme='animated'
              header='Dr Bot Assets'
              className='border-secondary w-15 '
            // getValue={value => console.log(value)}
            >
              <MDBTreeviewList icon='gem' title='Asset Schedular' opened >
                <MDBTreeviewItem onClick={() => this.handleClickfor('app_info')} far title='Application Health Configuration' />
                <MDBTreeviewItem onClick={() => this.handleClickfor('login')} title='Application Login Configuration' />
                <MDBTreeviewItem onClick={() => this.handleClickfor('vm_info')}  title='VM Health Configuration' />
                <MDBTreeviewItem onClick={() => this.handleClickfor('network_info')}  title='Network Health Configuration' />
              </MDBTreeviewList>
            </MDBTreeview>
          </MDBCol>
          <MDBCol md="9">
            <MDBContainer fluid className='mt-5'>
              {this.state.currentComponent === 'app_info' ? <ApplicationInfo></ApplicationInfo> : null}
              {this.state.currentComponent === 'login' ? <ApplicationLogin></ApplicationLogin> : null}
              {this.state.currentComponent === 'vm_info' ? <VMHealthInfo></VMHealthInfo> : null }
              {this.state.currentComponent === 'network_info' ? <NetworkHealthInfo></NetworkHealthInfo> : null }
            </MDBContainer>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      </div>
    );
  }
}

export default AdminPage;
