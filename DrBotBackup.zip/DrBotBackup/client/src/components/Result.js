import React from 'react';
import '../components/Component.css';

const Result = ({ children }) => {
  return (
    <div className='result-demo'>
      <div>{children}</div>
    </div>
  );
};

export default Result;