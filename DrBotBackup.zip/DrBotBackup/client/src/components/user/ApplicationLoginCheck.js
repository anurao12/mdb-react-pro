import React, { Component } from "react";
import {
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBContainer,
  MDBDataTable,
  MDBBtn,
  MDBSelect,
} from "mdbreact";
import moment from "moment";
import axios from "axios";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
};
class ApplicationLoginCheck extends Component {
  state = {
    isLoading: false,
    appInfo: [],
    appStatus: [],
    combinedApi: [],
    selectedRow: [],
    basicOptions: [],
    processName: [],
    appName: [],
    selectedProcessName: "",
    selectedAppName: "",
    dateMin: "",
    dateMax: "",
    setValue: 2,
  };

  AppOptionHandler = (g) => {
    this.setState({ selectedProcessName: g });
  };

  optionTypeHandler = (f) => {
    this.setState({ selectedAppName: f });
  };

  componentDidMount() {
    this.setState({ basicOptions: this.createOptions() });
    this.drawGrid(this.state.setValue);
  }

  submitHandler = (e) => {
    e.preventDefault();
    const appData = {
      app_name: this.state.selectedAppName,
      process_name: this.state.selectedProcessName,
    };
    this.setState({ isLoading: true });
    axios
      .post("/appLoginCheck", appData, { headers: headers })
      .then((response) => {
        this.drawGrid(this.state.setValue);
      })
      .catch((err) => console.log(err));
  };

  newArray = [];

  drawGrid = (value) => {
    // console.log(value)
    this.setState({ isLoading: true });
    //console.log(this.state.combinedApi);
    fetch("/loginAppName", {  method: "GET",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
    },})
      .then((response) => response.json())
      .then((data) => {
        data.response.map((item) => {
            item.value = item.value.toString();
          });
          this.setState({ appName: data.response });

        fetch("/loginProcessName",{ method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        },})
          .then((response) => response.json())
          .then((data) => {
            data.response.map((item) => {
                item.value = item.value.toString();
              });
              this.setState({ processName: data.response });

            fetch("/applogin", {  method: "GET",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Headers": "Content-Type",
              "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
            }, })
              .then((response) => response.json())
              .then((data) => {
                this.setState({ appInfo: data.response });

                let dateMin = this.getValueOfSelect(value);

                fetch(
                  "/appStatusList/" +
                    dateMin +
                    "/" +
                    moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
                  {
                    method: "GET",
                    headers: {
                      "Content-Type": "application/json",
                      "Access-Control-Allow-Origin": "*",
                      "Access-Control-Allow-Headers": "Content-Type",
                      "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                    },
                  }
                )
                  .then((response) => response.json())
                  .then((data) => {
                    this.state.appInfo.map((item, i) => {
                      let result = data.soapResult.completedItems.filter(
                        function (data) {
                          return item.process_name == data.name;
                        }
                      );
                      result.map((keys) => {
                        this.newArray.push({
                          id: item.app_id,
                          application_name: item.process_name,
                          application_url: item.app_url,
                          application_type: item.app_type_id,
                          status: keys.status,
                          date: moment(keys.date)
                            .local()
                            .format("YYYY-MM-DD HH:mm:ss")
                        });
                      });
                    });

                    this.setState(
                      {
                        combinedApi: this.newArray,
                      },
                      () => {
                        this.newArray = [];
                        this.setState({ isLoading: false });
                      }
                    );
                    //console.log(this.state.combinedApi);
                  })
                  .catch((err) => {
                    console.log(err);
                  });
              });
          });
      });
  };
  createOptions = () => [
    {
      checked: true,
      disabled: false,
      text: "Last 2 Hours",
      value: "2",
    },
    {
      checked: false,
      disabled: false,
      text: "Last 4 Hours",
      value: "4",
    },
    {
      checked: false,
      disabled: false,
      text: "Last 12 Hours",
      value: "12",
    },
    {
      checked: false,
      disabled: false,
      text: "Last 7 Days",
      value: "168",
    },
  ];

  getValueOfSelect = (value) => {
    //console.log(value);
    let HoursBefore = new Date();
    HoursBefore.setHours(HoursBefore.getHours() - parseInt(value));
    const dateMin = moment(HoursBefore).format("YYYY-MM-DD HH:mm:ss");
    return dateMin;
    //this.setState({ dateMin, dateMax });
  };

  render() {
    const { basicOptions, appName, processName } = this.state;
    const data = {
      columns: [
        {
          label: "Id",
          field: "id",
        },
        {
          label: "Name",
          field: "application_name",
        },
        {
          label: "URL",
          field: "application_url",
        },
        {
          label: "Type",
          field: "application_type",
        },
        {
          label: "Status",
          field: "status",
        },
        {
          label: "Date",
          field: "date",
        },
      ],
      rows: this.state.combinedApi,
    };
    //console.log(this.state);
    return (
      <div>
        {!this.state.isLoading ? (
          <div>
              <h1>Application Login Check</h1>
            <form className="needs-validation" onSubmit={this.submitHandler}>
              <MDBContainer className="mt-3">
                <MDBRow className="d-flex justify-content-center">
                  <MDBCol md="4">
                    <MDBSelect
                      color="primary"
                      getTextContent={this.optionTypeHandler}
                      options={appName}
                      label="Application Name"
                    />
                  </MDBCol>

                  <MDBCol md="4">
                    <MDBSelect
                      color="primary"
                      getTextContent={this.AppOptionHandler}
                      options={processName}
                      label="Process Name"
                    />
                  </MDBCol>

                  <MDBBtn color="success" type="submit">
                    run
                  </MDBBtn>
                </MDBRow>

                <MDBRow className="d-flex justify-content-center">
                  <MDBCol md="3">
                    <MDBSelect
                      color="primary"
                      getValue={(e) =>
                        this.setState(
                          {
                            setValue: e[0],
                          },
                          () => {
                            this.drawGrid(this.state.setValue);
                          }
                        )
                      }
                      options={basicOptions}
                    />
                  </MDBCol>
                </MDBRow>

                <MDBRow className="py-3">
                  <MDBCol md="12">
                    <MDBCard>
                      <MDBCardBody>
                        <MDBDataTable striped bordered hover data={data} />
                      </MDBCardBody>
                    </MDBCard>
                  </MDBCol>
                </MDBRow>
              </MDBContainer>
            </form>
          </div>
        ) : (
          <div>
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b1/Loading_icon.gif" />
          </div>
        )}
      </div>
    );
  }
}

export default ApplicationLoginCheck;
