import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBContainer, MDBTreeview, MDBTreeviewList, MDBTreeviewItem  } from 'mdbreact';
import ApplicationHealthCheck from './ApplicationHealthCheck';
import ApplicationLoginCheck from './ApplicationLoginCheck';
import VmHealthCheck from './VmHealthCheck';
import NetworkHealthCheck from './NetworkHealthCheck';

class UserAssetsPage extends Component {
  state = {
    currentComponent: '',
  };

  handleClickfor = (comp) => {
    this.setState({ currentComponent: comp });
  }

  render() {

    return (
      <div style={{ marginTop: '30px' }}>
       <MDBContainer fluid>
        <MDBRow>
          <MDBCol md="3">
            <MDBTreeview
              theme='animated'
              header='Dr Bot'
              className='border-secondary w-15 '
              // getValue={value => console.log(value)}
              onClick={(value) => this.handleClickfor(value.target.innerText)}
            >
              <MDBTreeviewList icon='gem' title='Home'  far opened >
                <MDBTreeviewItem title='Job Status' />
                <MDBTreeviewItem title='Application Health Check' />
                <MDBTreeviewItem title='Application Login Check' />
                <MDBTreeviewItem title='VM Health Check' />
                <MDBTreeviewItem title='Network Health Check' />
              </MDBTreeviewList>
            </MDBTreeview>
          </MDBCol>
          <MDBCol md="9">
            <MDBContainer fluid className='mt-5'>
              {this.state.currentComponent === 'Application Health Check' ? <ApplicationHealthCheck></ApplicationHealthCheck> : null}
              {this.state.currentComponent === 'Application Login Check' ? <ApplicationLoginCheck></ApplicationLoginCheck> : null}
              {this.state.currentComponent === 'VM Health Check' ? <VmHealthCheck></VmHealthCheck> : null }
              {this.state.currentComponent === 'Network Health Check' ? <NetworkHealthCheck></NetworkHealthCheck> : null }
              {/* {this.state.currentComponent === 'network_check' ? <JobStatus></JobStatus> : null } */}
            </MDBContainer>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      </div>
    )
  }
}

export default UserAssetsPage;