import {combineReducers} from 'redux';
import commentsReducer from './comments';
import authReducer from './auth';
import errorReducer from './error';

export default combineReducers({
    comments: commentsReducer,
    auth: authReducer,
    error: errorReducer
});

