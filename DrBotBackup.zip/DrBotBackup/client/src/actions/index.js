import axios from 'axios';
import {CHANGE_AUTH, SAVE_COMMENT, GET_ERRORS} from './types';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export function saveComment(comment){
  return{
    type: SAVE_COMMENT,
    payload: comment
  }
}

export function changeAuth (isLoggedIn){
    return {
        type: CHANGE_AUTH,
        payload:isLoggedIn
    }
}

