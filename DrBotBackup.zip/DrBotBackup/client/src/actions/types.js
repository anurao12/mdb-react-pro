export const SAVE_COMMENT = '';
export const CHANGE_AUTH = 'change_auth';
export const GET_ERRORS = 'GET_ERRORS';
