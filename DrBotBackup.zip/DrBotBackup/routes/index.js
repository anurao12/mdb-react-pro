const express = require("express");
const router = express.Router();const dbConn = require('../lib/db');
const bodyParser = require("body-parser");
// parse requests of content-type - application/json
router.use(bodyParser.json());
// parse requests of content-type - application/x-www-form-urlencoded
router.use(bodyParser.urlencoded({ extended: true }));
//connection for bluepism
const path = require('path')
var soap = require('strong-soap').soap
var parseString = require('xml2js').parseString;
const { exec, spawn } = require('child_process');
const { resolve } = require("path");

const bluePrismUserName = 'admin' // 
const bluePrismPassword = 'Dec_2020@nu' // 

var WSDL = soap.WSDL

var url = 'http://127.0.0.1:8181/ws/ApplicationStatusList?wsdl' //  

var urlweb = 'http://127.0.0.1:8181/ws/ApplicationHealthCheckWeb?wsdl'  

var urldesktop = 'http://127.0.0.1:8181/ws/ApplicationLoginCheckWeb?wsdl'
var urlnetwork = 'http://127.0.0.1:8181/ws/NetWorkCheck?wsdl'
var urlvmhealth = 'http://127.0.0.1:8181/ws/VMHealthCheckCPU?wsdl'

var processlistUrl = 'http://127.0.0.1:8181/ws/ProcessNamesList?wsdl'

var ResourceListUrl = 'http://127.0.0.1:8181/ws/ResourceNamesList?wsdl'

const http_options = {
    wsdl_headers:{'Connection':'keep-alive'}
}

router.get('/api', (req,res) => res.send('REST-SOAP Proxy - Blue Prism From Nodejs - Blue Prism DX Team'))

router.get("/applicationInfo", (req, res) => {
    let sql = "SELECT * FROM app_information";
    dbConn.query(sql, (err, results) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "response": results }));
    });
  });

router.get("/applogin", (req, res)=>{
    let sql = "SELECT * FROM app_login_check";
    dbConn.query(sql, (err, results) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "response": results }));
    });
});

router.get("/vmCheck", (req, res)=>{
  let sql = "SELECT * FROM vm_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
});

router.get("/nwCheck", (req, res)=>{
  let sql = "SELECT * FROM network_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
});

//user view run drop down
//application health check 
router.get('/processName', (req,res)=>{
  let sql = "SELECT process_name as text, app_id as value FROM app_information";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/appName', (req,res)=>{
  let sql = "SELECT app_name as text, app_id as value FROM app_information";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

//applicationlogin check
router.get('/loginProcessName', (req,res)=>{
  let sql = "SELECT process_name as text, app_id as value FROM app_login_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/loginappName', (req,res)=>{
  let sql = "SELECT app_name as text, app_id as value FROM app_login_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

//vm health check
router.get('/vmProcessName', (req,res)=>{
  let sql = "SELECT process_name as text, vm_id as value FROM vm_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/vmName', (req,res)=>{
  let sql = "SELECT vm_name as text, vm_id as value FROM vm_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

//network Health check
router.get('/netappProcessName', (req,res)=>{
  let sql = "SELECT process_name as text, app_id as value FROM network_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/netappName', (req,res)=>{
  let sql = "SELECT app_name as text, app_id as value FROM network_health_check";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/netProcessName', (req,res)=>{
  let sql = "SELECT process_name as text, net_id as value FROM network_latency";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

router.get('/netName', (req,res)=>{
  let sql = "SELECT net_name as text, net_id as value FROM network_latency";
  dbConn.query(sql, (err, results) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "response": results }));
  });
})

//application configuration
router.post("/createApplicationInfo", (req, res)=> {
  let data = {app_name: req.body.app_name, app_url: req.body.app_url, process_name: req.body.process_name, app_type_id: req.body.app_type_id }
  let sql = "INSERT INTO app_information SET ?";
  try {
    dbConn.query(sql, data, (err) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "message": "application is created." }));
    });
  } catch (e) {
    res.send(JSON.stringify({ "status": 0, "message": " failure." }));
  }
})

router.put('/updateAppConfig', (req, res) => {
  let sql = "UPDATE app_information SET app_name='" + req.body.app_name + "', app_url='" + req.body.app_url + "' , process_name='" + req.body.process_name + "' , app_type_id='" + req.body.app_type_id + "' WHERE app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is updated." }));
  });
});

router.put('/deleteAppConfig', (req, res) => {
  let sql = "DELETE from app_information where app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is deleted." }));
  });
});

//application login configuration

router.post("/createApplicationLogin", (req, res)=> {
  let data = {app_name: req.body.app_name, app_url: req.body.app_url, process_name: req.body.process_name, app_type_id: req.body.app_type_id }
  let sql = "INSERT INTO app_login_check SET ?";
  try {
    dbConn.query(sql, data, (err) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "message": "application is created." }));
    });
  } catch (e) {
    res.send(JSON.stringify({ "status": 0, "message": " failure." }));
  }
})

router.put('/updateAppLogin', (req, res) => {
  let sql = "UPDATE app_login_check SET app_name='" + req.body.app_name + "', app_url='" + req.body.app_url + "' , process_name='" + req.body.process_name + "' , app_type_id='" + req.body.app_type_id + "' WHERE app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is updated." }));
  });
});

router.put('/deleteAppLogin', (req, res) => {
  let sql = "DELETE from app_login_check where app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is deleted." }));
  });
});

//Network Health Check

router.post("/createNetworkHealth", (req, res)=> {
  let data = {app_name: req.body.app_name, app_url: req.body.app_url, process_name: req.body.process_name, app_type_id: req.body.app_type_id }
  let sql = "INSERT INTO network_health_check SET ?";
  try {
    dbConn.query(sql, data, (err) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "message": "application is created." }));
    });
  } catch (e) {
    res.send(JSON.stringify({ "status": 0, "message": " failure." }));
  }
})

router.put('/updateNetworkHealth', (req, res) => {
  let sql = "UPDATE network_health_check SET app_name='" + req.body.app_name + "', app_url='" + req.body.app_url + "' , process_name='" + req.body.process_name + "' , app_type_id='" + req.body.app_type_id + "' WHERE app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is updated." }));
  });
});

router.put('/deleteNetworkHealth', (req, res) => {
  let sql = "DELETE from network_health_check where app_id=" + req.body.app_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is deleted." }));
  });
});

//Vm health Check

router.post("/createVMHealth", (req, res)=> {
  let data = {vm_name: req.body.vm_name, vm_url: req.body.vm_url, process_name: req.body.process_name, app_type_id: req.body.app_type_id }
  let sql = "INSERT INTO vm_health_check SET ?";
  try {
    dbConn.query(sql, data, (err) => {
      if (err) throw err;
      res.send(JSON.stringify({ "status": 200, "message": "application is created." }));
    });
  } catch (e) {
    res.send(JSON.stringify({ "status": 0, "message": " failure." }));
  }
})

router.put('/updateVMHealth', (req, res) => {
  let sql = "UPDATE vm_health_check SET vm_name='" + req.body.vm_name + "', vm_url='" + req.body.vm_url + "' , process_name='" + req.body.process_name + "' , app_type_id='" + req.body.app_type_id + "' WHERE vm_id=" + req.body.vm_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is updated." }));
  });
});

router.put('/deleteVMHealth', (req, res) => {
  let sql = "DELETE from vm_health_check where vm_id=" + req.body.vm_id;
  dbConn.query(sql, (err) => {
    if (err) throw err;
    res.send(JSON.stringify({ "status": 200, "message": "application is deleted." }));
  });
});


// BP Process Health Check
const clientPromise = new Promise((resolve, reject) => (
  soap.createClient(url, http_options, (err, client) => {
      err ? reject(err) : resolve(client)
  })))

  const clientPromiseweb = new Promise((resolve, reject) => (
    soap.createClient(urlweb, http_options, (err, client) => {
        err ? reject(err) : resolve(client)
    })))

    const clientPromiseDesktop = new Promise((resolve, reject) => (
      soap.createClient(urldesktop, http_options, (err, client) => {
          err ? reject(err) : resolve(client)
      })))

      const clientPromiseVM = new Promise((resolve, reject) => (
        soap.createClient(urlvmhealth, http_options, (err, client) => {
            err ? reject(err) : resolve(client)
        })))
    
        const clientPromiseNetwork = new Promise((resolve, reject) => (
          soap.createClient(urlnetwork, http_options, (err, client) => {
              err ? reject(err) : resolve(client)
          })))

          const clientPromiseProcList = new Promise((resolve, reject) => (
            soap.createClient(processlistUrl, http_options, (err, client) => {
                err ? reject(err) : resolve(client)
            })))

            const clientPromiseResourceList = new Promise((resolve, reject) => (
              soap.createClient(ResourceListUrl, http_options, (err, client) => {
                  err ? reject(err) : resolve(client)
              })))

router.post('/CheckApplication',  (req,res) => (clientPromiseweb.then(client => ({client, req}))
  .then(invokeHealthCheck)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeHealthCheck = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  console.log(`Api Start - ${new Date(dateStart)}`)
  console.log(req.body);
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  client.ApplicationHealthCheckWeb((err,result,envelope,soapHeader) => {
      var reBody = {};
      parseString(envelope, function (err, result) {

          var LaunchStatus = result['soap:Envelope']['soap:Body'][0].ApplicationHealthCheckWeb[0].LaunchStatus[0]._;
          var CurrentDate = result['soap:Envelope']['soap:Body'][0].ApplicationHealthCheckWeb[0].CurrentDate[0]._;
          //console.log(result['soap:Envelope']['soap:Body'][0].ApplicationHealthCheckWeb[0])
          
          reBody.name = req.body.process_name;
          reBody.status = LaunchStatus;
          reBody.date = CurrentDate;
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Api End = ${new Date(dateComplete)}`)
})})


router.post('/appLoginCheck',  (req,res) => (clientPromiseDesktop.then(client => ({client, req}))
  .then(invokeLoginCheck)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeLoginCheck = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  console.log(`Api Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  client.ApplicationLoginCheckWeb((err,result,envelope,soapHeader) => {
    var reBody = {};
      parseString(envelope, function (err, result) {
          // reBody = result['soap:Envelope']['soap:Body'][0].ApplicationLoginCheckDesktop[0].LoginStatus[0]._;

          var LoginStatus = result['soap:Envelope']['soap:Body'][0].ApplicationLoginCheckWeb[0].LoginStatus[0]._;
          var CurrentDate = result['soap:Envelope']['soap:Body'][0].ApplicationLoginCheckWeb[0].CurrentDate[0]._;
          //console.log(result['soap:Envelope']['soap:Body'][0].ApplicationHealthCheckWeb[0])
          
          reBody.status = LoginStatus;
          reBody.date = CurrentDate;

      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Api End = ${new Date(dateComplete)}`)
})})

router.post('/vmHealthCheck',  (req,res) => (clientPromiseVM.then(client => ({client, req}))
  .then(invokevmHealthCheck)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokevmHealthCheck = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  console.log(`Add Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  client.VMHealthCheckCPU((err,result,envelope,soapHeader) => {
    var reBody = {};
      parseString(envelope, function (err, result) {
          // reBody = result['soap:Envelope']['soap:Body'][0].VMHealthCheckCPU[0].OutResult[0]._;
          
          var VMStatus = result['soap:Envelope']['soap:Body'][0].VMHealthCheckCPU[0].OutResult[0]._;
          var CurrentDate = result['soap:Envelope']['soap:Body'][0].VMHealthCheckCPU[0].CurrentDate[0]._;
          
          reBody.status = VMStatus;
          reBody.date = CurrentDate;
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Add Completed = ${new Date(dateComplete)}`)
})})

router.post('/appNetworkCheck',  (req,res) => (clientPromiseNetwork.then(client => ({client, req}))
  .then(invokeNetworkCheck)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeNetworkCheck = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  console.log(`Add Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  client.NetWorkCheck((err,result,envelope,soapHeader) => {
      var reBody = {};
      parseString(envelope, function (err, result) {
        console.log(result['soap:Envelope']['soap:Body'][0]);
         // reBody = result['soap:Envelope']['soap:Body'][0].Ping[0].PingSuccess[0]._;
         var NetworkStatus = result['soap:Envelope']['soap:Body'][0].NetWorkCheck[0].NetworkStatus[0]._;
          var CurrentDate = result['soap:Envelope']['soap:Body'][0].NetWorkCheck[0].CurrentDate[0]._;
          
          reBody.status = NetworkStatus;
          reBody.date = CurrentDate;
         // console.log(result['soap:Envelope']['soap:Body'][0].Ping[0].PingSuccess[0]._)
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Add Completed = ${new Date(dateComplete)}`)
})})

router.post('/applicationLatency',  function(req, res) {
  console.log('application started');
  exec('ApplicationLatBat.bat', [1, 'https://appaccess.mphasis.com/'], (err, stdout, stderr) => {
    if (err) {
      console.error(err);
      return;
     }
     console.log(stdout);
     return res.status(200).send({soapResult:stdout})
   });
})

router.get('/VMUsageCheck',  (req,res) => (clientPromise.then(client => ({client, req}))
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((error ) => {
      return res.status(400).send({error})})
))

router.get('/appStatusList/:dateMin/:dateMax', (req,res) => (clientPromise.then(client => ({client, req}))
  .then(invokeappStatusList)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeappStatusList = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  // console.log(req.params.dateMin);
  // console.log(req.params.dateMax);
  console.log(`Api Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  // client.ApplicationStatusList({dateMin:'2020-02-02 09:47',dateMax: '2021-02-09 09:47'}, (err,result,envelope,soapHeader) => {
   client.ApplicationStatusList({dateMin:req.params.dateMin,dateMax:req.params.dateMax}, (err,result,envelope,soapHeader) => {
      var reBody = {};
     // console.log('2', result);
      // console.log('3', envelope);
      parseString(envelope, function (err, result) {
         //console.log(result['soap:Envelope']['soap:Body'][0].ApplicationStatusList[0]);
         reBody.completedItems = JSON.parse(result['soap:Envelope']['soap:Body'][0].ApplicationStatusList[0].OutResult[0]._);

        //  reBody.scheduledItems = JSON.parse(result['soap:Envelope']['soap:Body'][0].ApplicationStatusList[0].ScheduleResult[0]._);

         // reBody.data = firstone.concat(secondone);
         
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Api End = ${new Date(dateComplete)}`)
})})


router.get('/appProcessList', (req,res) => (clientPromiseProcList.then(client => ({client, req}))
  .then(invokeappProcessList)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeappProcessList = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  // console.log(req.params.dateMin);
  // console.log(req.params.dateMax);
  console.log(`Api Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  // client.ApplicationStatusList({dateMin:'2020-02-02 09:47',dateMax: '2021-02-09 09:47'}, (err,result,envelope,soapHeader) => {
   client.ProcessNamesList((err,result,envelope,soapHeader) => {
      var reBody = {};
     // console.log('2', result);
      // console.log('3', envelope);
      parseString(envelope, function (err, result) {
        // console.log(result['soap:Envelope']['soap:Body'][0].ProcessNamesList[0].ProcessList[0]);
         reBody.ProcessList = JSON.parse(result['soap:Envelope']['soap:Body'][0].ProcessNamesList[0].ProcessList[0]._);
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Api End = ${new Date(dateComplete)}`)
})})

router.get('/appResourcesList', (req,res) => (clientPromiseResourceList.then(client => ({client, req}))
  .then(invokeappResourceList)
  .then((results) =>{ return res.status(200).send({soapResult:results})})
  .catch((  error ) => {
      return res.status(400).send({error})})
))

const invokeappResourceList = ({client, req}) => new Promise((resolve, reject) => {
  const dateStart = Date.now()
  // console.log(req.params.dateMin);
  // console.log(req.params.dateMax);
  console.log(`Api Start - ${new Date(dateStart)}`)
  client.setSecurity(new soap.BasicAuthSecurity(bluePrismUserName,bluePrismPassword))
  // client.ApplicationStatusList({dateMin:'2020-02-02 09:47',dateMax: '2021-02-09 09:47'}, (err,result,envelope,soapHeader) => {
   client.ResourceNamesList((err,result,envelope,soapHeader) => {
      var reBody = {};
     // console.log('2', result);
      // console.log('3', envelope);
      parseString(envelope, function (err, result) {
        console.log(result['soap:Envelope']['soap:Body'][0].ResourceNamesList[0].ProcessList[0]);
         reBody.ResourceList = JSON.parse(result['soap:Envelope']['soap:Body'][0].ResourceNamesList[0].ProcessList[0]._);
      });
      err  ? reject(err) : resolve(reBody)
  const dateComplete = Date.now()
  console.log(`Api End = ${new Date(dateComplete)}`)
})})


function setUrl (req) {
  url = req;
}

// const bat = spawn('"ApplicationLatBat.bat"', [1, 'https://appaccess.mphasis.com/'], { shell: true });

module.exports = router;

